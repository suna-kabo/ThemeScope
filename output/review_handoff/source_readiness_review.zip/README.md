# Source Readiness Review Handoff

Package created: 2026-10-30T04:06+08:00 (Asia/Hong_Kong).
Checkout base commit: `2a8ce9b9475b20b10ace1310ea9784645fd31df4` (branch `download`).
The five included source/report files reflect the current working-tree versions at package time; the base commit above predates these local edits. The package is the review snapshot, not a release artifact.

## Configuration versions

```json
{
  "config/active_anchors.json": {
    "reviewed_date": "2026-10-24",
    "source_session": "2026-10-23",
    "version": 1
  },
  "config/approved_release.json": "approved-1",
  "config/calendars/xnys_2020_2035_v1.json": {
    "schema_version": 1,
    "verified_through": "2027-12-31"
  },
  "config/membership_review_2026-10-29.json": {
    "reviewed_date": "2026-10-29",
    "schema_version": 1
  },
  "config/release_blockers.json": {
    "reviewed_date": "2026-10-30"
  },
  "config/theme_watchlists.json": {
    "reviewed_date": "2026-10-29",
    "version": 2
  }
}
```

## Included files and source file dates (filesystem mtime in UTC)

| Relative path | Source/review date | File mtime (UTC) | SHA-256 |
|---|---|---|---|
| `config/release_blockers.json` | terms and source review through 2026-10-30 | 2026-10-29T20:04:53+00:00 | `7849286913a77093b32051fe1ce7db34e6489328b741a93d6a2cebec7c397269` |
| `config/candidate_source_review_2026-10-29.json` | source review/captures 2026-10-29 | 2026-10-29T19:29:06+00:00 | `d509b97521ee937372849ebb6233ddf8a0230f9ff0cfea97d5210e99df33c0aa` |
| `docs/approved_roster_inputs.md` | document review 2026-10-30 | 2026-10-29T20:01:25+00:00 | `d43d7ffe0c666da5bcdebc8a8b81da43bed7b31d6ba5a23c07efa849b395b8ea` |
| `docs/approved_implementation.md` | document review 2026-10-30 | 2026-10-29T20:04:37+00:00 | `73ff636029513951b814130056b0102366bc6d1b7a07a67f087e5b4cf2d74b10` |
| `output/approved_maintenance/approved_release_audit.json` | audit_date 2026-10-30 | 2026-10-29T20:05:22+00:00 | `a051ab7da2568a63c3263f04b32e86a9576af3c49d081bfd1decb43626c8b6e8` |

## File reconciliation

All five requested report/input paths were present. No requested file was renamed, and no equivalent-file substitution was needed.

The archive excludes credentials, environment files, raw market histories, cached price data, generated data-bearing dashboards/CSVs, and the separate IWM candidate-roster snapshot. The IWM source-row evidence and provider-status findings are summarized in the included blocker record; the roster file itself is not included.

The audit remains incomplete (`release_passed: false`). The 47/53 historical breadth count is explicitly tied to the 25 October v2 configuration; current applied v2 capacity is 46/53. The final full-roster manifest is not generated because the SPY/QQQ rosters and remaining source/provider validations are unresolved.
