# Rights-cleared roster inputs

The collector expects these paths, already referenced from `config/approved_release.json`:

- `config/rosters/spy_sp500.json` — S&P 500 index constituents required for SPY breadth.
- `config/rosters/qqq_nasdaq100.json` — Nasdaq-100 index constituents required for QQQ breadth.
- `config/rosters/iwm_holdings_proxy.json` — actual dated iShares IWM equity holdings, used only as a Russell 2000 proxy.

No placeholder constituents or inferred effective dates are supplied. S&P 500 and Nasdaq-100 rights-cleared roster files are not available. The latest official iShares file retrieved 29 October is as of 28 October 2026. `config/rosters/iwm_holdings_proxy_candidate.json` contains 1,963 normalized source identities, 12 explicitly excluded rows, and one unresolved source identity; it is not the approved IWM roster. BlackRock's published terms permit personal local download; no bespoke permission is required for this private use. The SEC company/ticker/exchange crosswalk resolves four `TXE` aliases to TXSE and four class-symbol normalizations. An issuer SEC-filed release resolves Verdera Energy's VUECF share listing as OTCQB:VUECF / TSXV:V; it is included as an IWM equity holding. Alpaca identity and data support remain untested for all 1,963 members.

The one unresolved source row is the no-ticker Coherus residual, separate from the known CHRS/Nasdaq row (price 0.00, quantity 3,271,222, value $32.71). The iShares file has no CUSIP, ISIN, FIGI, or share-class field for it, so it could be a CHRS residual or a different security. The smallest evidence needed is a per-row identifier/class mapping from BlackRock/iShares; do not merge it by issuer name. VUECF is not an unresolved membership decision: the source calls it Equity and the issuer filing identifies OTCQB:VUECF and TSXV:V. Its provider feed is a separate question: Alpaca's docs include `feed=otc`, but actual alias/access/bars are untested. PDLI, SBT, and THRD also remain in the source holdings denominator pending provider checks despite zero source prices and no current SEC crosswalk entry. The candidate file is rejected by `load_roster` while the Coherus identity row remains unresolved. S&P 500 and Nasdaq-100 require applicable licensed constituent sources.

Each approved source must have applicable date semantics and be normalized into this metadata contract:

```json
{
  "source": "official provider and source URL",
  "version": "provider file/version or retrieval identifier",
  "checksum": "sha256 of members JSON using sorted keys and compact separators",
  "retrieved_at": "timezone-aware ISO 8601 timestamp",
  "verified_at": "timezone-aware ISO 8601 timestamp",
  "date_semantics": "effective or observation, stated by the source",
  "valid_from": "YYYY-MM-DD",
  "valid_through": "YYYY-MM-DD",
  "members": [
    {"symbol": "AAPL", "identity": "US:NASDAQ:AAPL"}
  ],
  "mapping_decisions": [],
  "additions": [],
  "removals": []
}
```

For each file, calculate `checksum` over only the `members` array as serialized by:

```python
hashlib.sha256(json.dumps(members, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
```

Preserve distinct listed share classes. Do not label an observation date as an effective date. For IWM, preserve the issuer's actual holdings file date and do not call holdings Russell 2000 index constituents. All three approved paths remain absent. The target-applicable IWM source is captured; one Coherus source identity needs a row-level security identifier and Alpaca asset validation remains pending. SPY and QQQ require licensed constituent sources.
