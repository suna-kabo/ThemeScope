# Manual CSV run

US session: 2026-11-02

Market: Short bias

SPY and QQQ are both Bearish. Under the approved Market matrix, unanimous Bearish Price States produce Short bias. Combined Breadth is Mixed, which describes divided participation but does not reverse unanimous price direction.

Detailed metrics and input hashes: run_audit.json. TradingView platform import has not been performed.
