# Manual CSV refresh — US session 2 November 2026

Prepared 3 November 2026 Hong Kong time from the five newly supplied TradingView exports, without live collection. Source baseline: `8b71f30`. The files are named 2026-11-03; the declared as-of session is 2026-11-02, the latest completed XNYS session when processed (16:00 EST / 05:00 HKT the following day). The exports contain no quote/session timestamp column, so this is a contextual session declaration, not independent verification of each row's date.

| Role | Supplied file | Rows |
|---|---|---:|
| Stock | Daily_Stock_2026-11-03.csv | 1,546 |
| ETF | Daily_ETF_2026-11-03.csv | 6,116 |
| SPY breadth | SPY_2026-11-03.csv | 502 |
| QQQ breadth | QQQ_2026-11-03.csv | 101 |
| Russell 2000 breadth | IWM_2026-11-03.csv | 1,917 |

All **53 configured anchors** are present and score-eligible. All three supplied breadth universes produce valid index breadth. Theme Breadth is valid for **46/53** themes under the existing minimum-eight/coverage rules. The Market classification is Short bias; no classification or priority was hard-coded.

The fixed 563-stock universe and 901 many-to-many memberships are unchanged. The new Stock CSV matches 886 membership rows; **15 occurrences across 11 stocks** are unavailable: AG, AYA, CDE, GLXY, HL, KVUE, LBRT, LEU, SKWD, VC and WGS. Their memberships remain configured; missing metrics are not filled or substituted. Use the Daily Data Stocks list without screener filters when collecting future daily CSVs. This refresh does not establish complete daily stock data.

Real local history for **2026-10-30** was preserved byte-for-byte. All 53 rank changes now compare with that immediately preceding US session. The new **2026-11-02** record was added. The download copy includes both actual records; no synthetic history is included. The previous dated dashboard ZIP remains available as an archive.

The independent Primary-theme earnings union is 171 stocks: 56 supplied expected dates within 2–9 November inclusive, seven unknown/unavailable and 108 later. These remain expected dates; same-day timing is unverified.

## Import correction

The initial import correctly preserved the prior dashboard when it encountered blank 1-week Performance for VFPEF, an unused ETF. The reusable parser was corrected to allow audited blank numeric cells **only outside the configured anchor plus SPY/QQQ/IWM ETF universe**. The unmodified original input files remain the sources. This export contains 681 such blank cells across 346 unused ETFs; the precise cells are recorded in `run_audit.json` under the ETF input's numeric warnings. They are retained as missing, never imputed and never used in ranking or Market calculations.

Configured anchors/benchmarks still require their numeric metrics. Invalid numeric text, invalid positive values, missing required headers, duplicates and stock validation remain strict. Direct parser callers retain strict validation by default. No trading calculation, scanner floor, membership, identifier, view or export format changed.

## Checks and downloads

- 160 Python tests pass, including the new regression for unused ETF blanks, required ETF rejection, unchanged stock validation and rejection of malformed unused numeric values. Node helper tests pass.
- Actual five-file generation succeeded in **1.176s wall time through process exit**. Its internal pre-publication subtotal is 0.706s: 0.373s validation/calculation and 0.333s output generation/validation. Browser testing and investigation are separate.
- Export checks pass for all 53 individual files/ZIP/manifest, 563-stock collection list and optional deduplicated scans. All individual TXT contents are byte-identical to the prior research lists; daily reimport is unnecessary.
- Current-data Chromium navigation checks pass keyboard/mouse/touch, missing-data stock navigation, filtering/Back restoration, exports, desktop geometry and offline request checks: zero JavaScript errors and zero automatic external requests. The suite generated 32 fresh screenshots across both modes and four viewport sizes. The 1536×864 ETF tables were visually inspected in light and dark; not every captured screenshot was manually inspected in this refresh.
- Independent first-run/history/publication rollback checks pass with the new inputs. Earlier history hashes remain unchanged. The injected failure used temporary output only.

Latest download: `downloads/ThemeScope_manual_csv_session_2026-11-02.zip`. Extract the whole ZIP and open `dashboard.html`, retaining sibling exports and `individual_watchlists/`. If your browser blocks local files, run `python -m http.server 8000` from the extracted folder and open `http://localhost:8000/dashboard.html`.

Actual TradingView import remains unperformed here. Managed Chromium continues to block direct `file://` testing with `ERR_BLOCKED_BY_ADMINISTRATOR`; local HTTP rendering/downloads pass and browser policy is unchanged. No secrets or new credentials are needed for this manual workflow. Data-bearing artifacts are updated only in the confirmed private repository's `download` branch, with the user's standing authorization; no public publication or live reliability claim is made.
