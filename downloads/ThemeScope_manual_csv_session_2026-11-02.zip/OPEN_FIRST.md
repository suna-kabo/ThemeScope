# ThemeScope — US session 2 November 2026

Refreshed from the five supplied exports named 3 November 2026 (Hong Kong date).

Extract the whole ZIP and open dashboard.html. Keep sibling exports and individual_watchlists/ alongside it. If local files are blocked, run python -m http.server 8000 from this folder and open http://localhost:8000/dashboard.html.

Rank changes compare against the real 30 October session. Both real local_history records are included. Preserve local_history/ for future runs.

All 53 anchors are present. Eleven configured stocks are absent from the supplied Stock CSV; unavailable rows are retained. See REFRESH_AUDIT.md and run_audit.json for exact coverage and input warnings.

Research memberships and individual watchlists are unchanged. You do not need to reimport those lists daily. Daily Data Stocks — export CSV only remains the complete fixed collection list.

Actual TradingView imports and direct file:// browser behavior remain unverified here; local HTTP browser checks pass.
