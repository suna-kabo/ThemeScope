# ThemeScope v7.1 run report

Market session: 2026-10-23

Dashboard generated: 2026-10-25T03:36:36+00:00

Workflow: normal cached market refresh

## Ranking and state

Current is the percentile rank of 21-session ETF excess return versus SPY. Medium is the 63-session percentile. Theme Score remains `0.60 × Current + 0.40 × Medium`, with the configured 50 state threshold. Theme and index breadth do not affect score, state, or rank.

## Watchlist configuration

- Active exposures: 53; inactive exposures: 0; rejected candidate ETF rows: 0.
- Final reviewed lists: 53/53 (complete 44; reviewed short 9; reviewed ETF-only 0); stored records 53.
- Configured memberships: 772; unique stocks: 510; overlapping stocks: 175 (262 additional memberships).
- Themes with valid EMA21 breadth: 47; with valid EMA50 breadth: 47.
- Lists: Communication Services (20, complete), Consumer Discretionary (20, complete), Consumer Staples (20, complete), Energy (20, complete), Financials (20, complete), Health Care (20, complete), Industrials (20, complete), Information Technology (20, complete), Materials (20, complete), Real Estate (20, complete), Utilities (20, complete), Semiconductors (15, complete), Software (15, complete), Cloud Computing (15, complete), Cybersecurity (15, complete), Internet (15, complete), Artificial Intelligence & Big Data (15, complete), Robotics & Automation (15, complete), Quantum Computing (12, reviewed_short), Blockchain & Digital-Asset Companies (11, reviewed_short), Autonomous & Electric Vehicles (15, complete), Biotechnology (15, complete), Pharmaceuticals (15, complete), Medical Devices (15, complete), Healthcare Providers (15, complete), Genomics (15, complete), Aerospace & Defense (15, complete), Space Economy (15, complete), US Infrastructure (15, complete), Transportation (15, complete), Airlines (6, reviewed_short), Agribusiness (15, complete), Oil & Gas Exploration & Production (15, complete), Oil Services (15, complete), Midstream & MLP Infrastructure (15, complete), Natural Gas Companies (15, complete), Clean Energy (15, complete), Solar (6, reviewed_short), Uranium Miners (1, reviewed_short), Nuclear Energy (15, complete), Lithium & Battery Technology (9, reviewed_short), Copper Miners (5, reviewed_short), Rare Earth & Strategic Materials (15, complete), Gold Miners (15, complete), Silver Miners (6, reviewed_short), Diversified Metals & Mining (15, complete), Regional Banks (15, complete), Insurance (15, complete), Broker-Dealers & Capital Markets (15, complete), Homebuilders (15, complete), Retail (15, complete), Residential Real Estate (15, complete), Mortgage REITs (1, reviewed_short).
- Release audit: PASS.

## Cache and requests

- Persistent cache: 2,563 hits; 0 incremental updates; 97 full refreshes; 0 failures; 0 stale series reused.
- Source requests by category: price histories 97; index universes 0; filings 0; company quotes 0; theme holdings 0; AUM/spread 0.
- A rerender/import uses no network requests. Request totals shown here count actual collector fetches, not cache hits.

## Breadth and limits

- Theme breadth uses the fixed configured list and displays above/valid counts. Validity requires at least 8 observations and at least 80% of configured members. A missing ticker stays in the configured denominator.
- Five-session breadth change uses the same current membership at both dates; it is not a historical point-in-time universe.
- Index breadth remains separate: SPY uses observed S&P 500 constituents, QQQ uses Nasdaq-100, and IWM uses current holdings as a practical Russell 2000 proxy.
- A release requires one reviewed configuration record for each active exposure; incomplete records block publishing and are not represented as awaiting a future CSV.
- Normal refresh reads the approved static membership and does not run classification research, full ETF holdings breadth, AUM, spreads, or daily market-cap requests.

## Files

The run bundle includes the dashboard, compact snapshot and CSVs, configuration, and compressed price sidecars. Run `python3 scripts/generate_dashboard.py --import-run output` to rerender without network access.
