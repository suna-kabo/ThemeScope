# Open ThemeScope

Data session: 30 October 2026. Updated quiet research terminal interface.

1. Extract the entire ZIP to one folder.
2. Open dashboard.html in Chrome, Edge or Firefox. No install/server is required to view it.
3. Keep all sibling TXT, CSV and ZIP exports beside the HTML.

New daily data: use the repository README five-file TradingView CSV command, declare the real US session, and reuse the same output folder to retain local_history/. No credentials are needed for this workflow.

The included RELEASE_AUDIT.md records checks and specific validation limits. This bundle does not contain a newer market session. Actual TradingView import remains untested.
