# Open ThemeScope

Data session: 30 October 2026. Individual exports and offline navigation update.

Extract the whole ZIP and open dashboard.html. Keep individual_watchlists/ and sibling files beside it.

Research: use Download all individual watchlists (one ZIP), or Download selected watchlist. Files start with the ETF ticker and contain that ETF first, then configured stocks. Update only when memberships or identifiers change.

Daily data: use Daily Data Stocks — export CSV only to collect your daily Stock CSV. Do not reimport every research list each day.

Find navigates across stocks/themes. The lower Search filters the current Watchlist. ETF 1D % is sortable beside ETF.

New data: run the repository README five-file CSV command with the real US session and preserve local_history/. No secrets are needed for this workflow.

Read RELEASE_AUDIT.md for validation and specific limits. Revised TradingView imports have not been performed here. Managed Chromium blocked direct file:// testing; local HTTP tests passed. If your browser also blocks local files, serve the extracted folder locally with python -m http.server 8000 and open http://localhost:8000/dashboard.html.
